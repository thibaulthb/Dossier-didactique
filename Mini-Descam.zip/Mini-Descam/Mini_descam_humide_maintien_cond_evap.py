#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 17:47:58 2022

@author: thibault
"""

## Importation des bibliotheques
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons
from numpy import pi
# format vectoriel par défaut des images
from IPython.display import set_matplotlib_formats
set_matplotlib_formats('svg')

#Définition des constantes principales
grav=9.81   #m/s²
Cp=1006     #J/K/kg
Cw=4180     #J/K/kg
Lv=2500e3   #J/kg
R=8.314     #J/K/mol
M=29e-3     #kg/mol
Mw=18e-3    #kg/mol
gamma=1.4   #Sans Unités
T0=273.15   #K

#Définitions des paramètres initiaux de la simulation
Te0=300     #K
T1=303      #K
p0=101300   #Pa
dt=2        #s

def T_std(z):
    return Te0-6.5e-3*z

def T_par(z,z_amont,T_amont):
    return T_amont*(p_std(z_amont)/p_std(z))**((1-gamma)/gamma)

def p_std(z):
    return p0*(1-6.5e-3*z/Te0)**(M*grav/(6.5e-3*R))

def dp_std(z):
    return -p0*(6.5e-3/Te0)*(M*grav/(6.5e-3*R))*(1-6.5e-3/Te0*z)**(M*grav/(6.5e-3*R)-1)

def theta(T,p):
    return T*(p0/p)**(R/Cp)

def rho(z,T,r):
    return p_std(z)*M/(R*T)*(1+r)/(1+M/Mw*r)

def psatw(T):
    return 611*np.exp(17.502*(T-T0)/(T-32.19))

def psati(T):
    return 611*np.exp(22.587*(T-T0)/(T+0.7))

def slwv(T):
    return 2.5e6-2.34e3*(T-T0)

def mix_rat(p_w,p):
    return Mw/M*p_w/p

alt_dyn=np.zeros(1000)
vit_dyn=np.zeros(1000)
T_dyn=np.zeros(1000)
pw_dyn=np.zeros(1000)
qc_dyn=np.zeros(1000)
r_dyn=np.zeros(1000)
temps = np.arange(0,2000,dt)
T_dyn[0] = T1
pw_dyn[0] = 0.2627*psatw(T_dyn[0])
pw_dyn[0] = 0.23*psatw(T_dyn[0])
r_dyn[0]=mix_rat(pw_dyn[0],p_std(alt_dyn[0]))
#print(pw_dyn[0])


for i in range (1,len(temps)):
    vit_dyn[i] = vit_dyn[i-1] + (-1/(rho(alt_dyn[i-1],T_dyn[i-1],r_dyn[i-1])+qc_dyn[i])*dp_std(alt_dyn[i-1])-grav)*dt
    alt_dyn[i] = alt_dyn[i-1] + vit_dyn[i]*dt
    T_dyn[i]   = T_par(alt_dyn[i],alt_dyn[i-1],T_dyn[i-1])
    pw_dyn[i]  = pw_dyn[i-1]
    qc_dyn[i]  = qc_dyn[i-1]
    r_dyn[i]   = mix_rat(pw_dyn[i],p_std(alt_dyn[i]))
    if pw_dyn[i] > psatw(T_dyn[i]):
        T_store   = T_dyn[i]
        cond      = (pw_dyn[i]-psatw(T_dyn[i]))*Mw/(R*T_dyn[i])
        qc_dyn[i] = qc_dyn[i]+cond
        T_dyn[i]  = T_dyn[i]+slwv(T_dyn[i])*cond/(Cp*rho(alt_dyn[i],T_dyn[i],r_dyn[i])+Cw*qc_dyn[i])
        pw_dyn[i] = psatw(T_store)
        r_dyn[i]  = mix_rat(pw_dyn[i],p_std(alt_dyn[i]))
    else:
        if qc_dyn[i]>0:
            T_store   = T_dyn[i]
            evap      = -min(qc_dyn[i],-(pw_dyn[i]-psatw(T_dyn[i]))*Mw/(R*T_dyn[i]))
            qc_dyn[i] = qc_dyn[i] + evap
            T_dyn[i]  = T_dyn[i]+slwv(T_dyn[i])*evap/(Cp*rho(alt_dyn[i],T_dyn[i],r_dyn[i])+Cw*(qc_dyn[i]))
            pw_dyn[i] = pw_dyn[i] - evap*(R*T_store)/Mw
            r_dyn[i]  = mix_rat(pw_dyn[i],p_std(alt_dyn[i]))
    
#Création de la fenêtre
fig, ax = plt.subplots(figsize=(8,5))
#plt.subplots_adjust(bottom=0.25,left=0.1,right=.7)         # dimensions du graphique

altitude=np.linspace(0,4000,101)

plt.plot(T_std(altitude),altitude)
plt.plot(theta(T_std(altitude),p_std(altitude)),altitude)
plt.plot(T_dyn,alt_dyn,'g-')
plt.plot(theta(T_dyn*(1+1.608*r_dyn)/(1+r_dyn),p_std(alt_dyn)),alt_dyn,'r-')

plt.axis([270, 310, 0, 4000])                     # limite des axes (xmin,xmax,ymin,ymax)
plt.xlabel("Température (K)")                     # titre de l'axe des abscisses
plt.ylabel("Altitude (m)")                               # titre de l'axe des ordonnees
plt.title("Profil de température") 

plt.show()

plt.plot(p_std(altitude),altitude)

plt.axis([60000, 102000, 0, 4000])                     # limite des axes (xmin,xmax,ymin,ymax)
plt.xlabel("Pression (Pa)")                     # titre de l'axe des abscisses
plt.ylabel("Altitude (m)")                               # titre de l'axe des ordonnees
plt.title("Profil de pression") 

plt.show()

plt.plot(temps,alt_dyn)

plt.axis([0, 2000, 0, 4000])                     # limite des axes (xmin,xmax,ymin,ymax)
plt.xlabel("Temps (s)")                     # titre de l'axe des abscisses
plt.ylabel("Altitude (m)")                               # titre de l'axe des ordonnees
plt.title("Évolution adiabatique d'une masse d'air sec") 

plt.show()

plt.plot(temps,pw_dyn/psatw(T_dyn))

plt.axis([0, 2000, 0, 1.25])                     # limite des axes (xmin,xmax,ymin,ymax)
plt.xlabel("Temps (s)")                     # titre de l'axe des abscisses
plt.ylabel("Humidité relative")                               # titre de l'axe des ordonnees
plt.title("Évolution adiabatique d'une masse d'air humide") 

plt.show()

plt.plot(temps,T_dyn)

plt.axis([0, 2000, 270, 310])                     # limite des axes (xmin,xmax,ymin,ymax)
plt.xlabel("Temps (s)")                     # titre de l'axe des abscisses
plt.ylabel("Humidité relative")                               # titre de l'axe des ordonnees
plt.title("Évolution adiabatique d'une masse d'air humide") 

plt.show()

plt.plot(temps,qc_dyn)

plt.axis([0, 2000, 0, 3e-3])                     # limite des axes (xmin,xmax,ymin,ymax)
plt.xlabel("Temps (s)")                     # titre de l'axe des abscisses
plt.ylabel("Humidité relative")                               # titre de l'axe des ordonnees
plt.title("Évolution adiabatique d'une masse d'air humide") 

plt.show()