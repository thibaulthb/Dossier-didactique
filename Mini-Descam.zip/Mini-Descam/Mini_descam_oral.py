#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Jun  8 17:47:58 2022

@author: thibault
"""

## Importation des bibliotheques
import numpy as np
import matplotlib.pyplot as plt
from matplotlib.widgets import Slider, Button, RadioButtons, CheckButtons
from numpy import pi
# format vectoriel par défaut des images
from IPython.display import set_matplotlib_formats
set_matplotlib_formats('svg')

#Définition des constantes principales
grav=9.81   #m/s²
Cp=1006     #J/K/kg
Cw=4180     #J/K/kg
Lv=2500e3   #J/kg
R=8.314     #J/K/mol
M=29e-3     #kg/mol
Mw=18e-3    #kg/mol
gamma=1.4   #Sans Unités
T0=273.15   #K
Te0=300     #K
p0=101300   #Pa

def T_std(z,Gamma):
    return Te0-Gamma*z

def T_par(z,z_amont,T_amont,Gamma):
    return T_amont*(p_std(z_amont,Gamma)/p_std(z,Gamma))**((1-gamma)/gamma)

def p_std(z,Gamma):
    return p0*(1-Gamma*z/Te0)**(M*grav/(Gamma*R))

def dp_std(z,Gamma):
    return -p0*(Gamma/Te0)*(M*grav/(Gamma*R))*(1-Gamma/Te0*z)**(M*grav/(Gamma*R)-1)

def theta(T,p):
    return T*(p0/p)**(R/Cp)

def rho(z,T,r,p):
    return p*M/(R*T)*(1+r)/(1+M/Mw*r)

def rho_dry(T,p):
    return p*M/(R*T)

def psatw(T):
    return 611*np.exp(17.502*(T-T0)/(T-32.19))

def psati(T):
    return 611*np.exp(22.587*(T-T0)/(T+0.7))

def slwv(T):
    return 2.5e6-2.34e3*(T-T0)

def mix_rat(p_w,p):
    return Mw/M*p_w/p

# Initialisation des valeurs à stocker

global alt_dyn,vit_dyn,T_dyn,pw_dyn,qc_dyn,r_dyn
alt_dyn=np.zeros(4000)
vit_dyn=np.zeros(4000)
T_dyn=np.zeros(4000)
pw_dyn=np.zeros(4000)
qc_dyn=np.zeros(4000)
r_dyn=np.zeros(4000)
temps=np.zeros(4000)
    
#Création de la fenêtre
fig = plt.figure(constrained_layout=True, figsize=(14,10))
gs = fig.add_gridspec(ncols=14, nrows=10)
ax_T = fig.add_subplot(gs[0:3,0:3])
ax_p = fig.add_subplot(gs[0:3,3:6])
ax_alt = fig.add_subplot(gs[3:8,0:6])
ax_RH = fig.add_subplot(gs[8:10,0:3])
ax_qc = fig.add_subplot(gs[8:10,3:6])
#plt.subplots_adjust(bottom=0.25,left=0.1,right=.7)         # dimensions du graphique

# Mise en place des contrôles
axcolor = 'white'
rax = plt.axes([.75, 0.73, 0.2, 0.25])
radio = RadioButtons(rax, ("Création du profil", "Parcelle d'air sec",
                           "Parcelle d'air humide","Condensation irréversible",
                           "Condensation sans perte","Condensation/évaporation",
                           "Condensation bridée"))
mode=radio.value_selected
# for r in cb.rectangles:
#     r.set_facecolor("blue") 
#     r.set_edgecolor("k")
axT = plt.axes([0.75, 0.30, .2, 0.03], facecolor=axcolor)
sl_axT = Slider(axT, '$T_{ini}$(K)', 290, 310, valinit=303, valstep=0.1)  
T_ini=sl_axT.val                       #Slider pour modifier le temps
axRH = plt.axes([0.75, 0.25, .2, 0.03], facecolor=axcolor)
sl_axRH = Slider(axRH, "$RH_{ini}$", 0.2, 0.5, valinit=0.262, valstep=0.001) 
RH_ini=sl_axRH.val                        #Slider pour modifier la vitesse
axGamma = plt.axes([0.75, 0.20, .2, 0.03], facecolor=axcolor)
sl_axGamma = Slider(axGamma, r"$\Gamma_z$(K/km)", 5, 12, valinit=6.5, valstep=0.1) 
Gamma=sl_axGamma.val*1e-3                        #Slider pour modifier la vitesse
axdt = plt.axes([0.75, 0.15, .2, 0.03], facecolor=axcolor)
sl_axdt = Slider(axdt, "dt (s)", 0.5, 10, valinit=2, valstep=0.1) 
pas_temps=sl_axdt.val                        #Slider pour modifier la vitesse
axcond = plt.axes([0.75, 0.05, .2, 0.03], facecolor=axcolor)
sl_axcond = Slider(axcond, "Temps de condensation/évaporation (s)", 0.5, 20, valinit=1, valstep=0.05) 
condrate=sl_axcond.val                        #Slider pour modifier la vitesse
sl_axcond.label.set_position([1,1.5])

def Mini_descam(dt,T1,RH_ini,Gamma,mode,condrate):
    global alt_dyn,vit_dyn,T_dyn,pw_dyn,qc_dyn,r_dyn
    
    if mode == "Condensation bridée":
        cond_rate=min(dt/condrate,1)
    else:
        cond_rate=1
    if mode != "Création du profil":
        T_dyn[0]   = T1
        if mode != "Parcelle d'air sec":
            pw_dyn[0]  = RH_ini*psatw(T_dyn[0])
            r_dyn[0]   = mix_rat(pw_dyn[0],p_std(alt_dyn[0],Gamma))
        
        nmax=int(np.floor(2000/dt))
        for i in range (1,nmax):
            if mode == "Parcelle d'air sec":
                vit_dyn[i] = vit_dyn[i-1] + (-1/(rho_dry(T_dyn[i-1],p_std(alt_dyn[i-1],Gamma)))*dp_std(alt_dyn[i-1],Gamma)-grav)*dt
            else:
                vit_dyn[i] = vit_dyn[i-1] + (-1/(rho(alt_dyn[i-1],T_dyn[i-1],r_dyn[i-1],p_std(alt_dyn[i-1],Gamma))+qc_dyn[i-1])*dp_std(alt_dyn[i-1],Gamma)-grav)*dt
            alt_dyn[i] = alt_dyn[i-1] + vit_dyn[i]*dt
            T_dyn[i]   = T_par(alt_dyn[i],alt_dyn[i-1],T_dyn[i-1],Gamma)
            pw_dyn[i]  = pw_dyn[i-1]
            qc_dyn[i]  = qc_dyn[i-1]
            r_dyn[i]   = mix_rat(pw_dyn[i],p_std(alt_dyn[i],Gamma))
            if mode == "Condensation irréversible" or mode == "Condensation sans perte" or mode == "Condensation/évaporation" or mode == "Condensation bridée":
                if pw_dyn[i] > psatw(T_dyn[i]):
                    T_store   = T_dyn[i]
                    cond      = cond_rate*(pw_dyn[i]-psatw(T_dyn[i]))*Mw/(R*T_dyn[i])
                    if mode != "Condensation irréversible":
                        qc_dyn[i] = qc_dyn[i]+cond
                    T_dyn[i]  = T_dyn[i]+slwv(T_dyn[i])*cond/(Cp*rho(alt_dyn[i],T_dyn[i],r_dyn[i],p_std(alt_dyn[i],Gamma))+Cw*qc_dyn[i])
                    pw_dyn[i] = pw_dyn[i] - cond*(R*T_store)/Mw
                    r_dyn[i]  = mix_rat(pw_dyn[i],p_std(alt_dyn[i],Gamma))
                else:
                    if mode == "Condensation/évaporation" or mode == "Condensation bridée":
                        if qc_dyn[i]>0:
                            T_store   = T_dyn[i]
                            evap      = -cond_rate*min(qc_dyn[i],-(pw_dyn[i]-psatw(T_dyn[i]))*Mw/(R*T_dyn[i]))
                            qc_dyn[i] = qc_dyn[i] + evap
                            T_dyn[i]  = T_dyn[i]+slwv(T_dyn[i])*evap/(Cp*rho(alt_dyn[i],T_dyn[i],r_dyn[i],p_std(alt_dyn[i],Gamma))+Cw*(qc_dyn[i]))
                            pw_dyn[i] = pw_dyn[i] - evap*(R*T_store)/Mw
                            r_dyn[i]  = mix_rat(pw_dyn[i],p_std(alt_dyn[i],Gamma))
        
# Calcul initial
temps = np.arange(0,4000*pas_temps,pas_temps)
Mini_descam(pas_temps, T_ini, RH_ini, Gamma,mode,condrate)

nmax=int(np.floor(2000/pas_temps))
altitude=np.linspace(0,4000,101)

# Tracé du profil de température
ax_T.plot(T_std(altitude,Gamma),altitude)
ax_T.plot(theta(T_std(altitude,Gamma),p_std(altitude,Gamma)),altitude)
ax_T.plot(T_dyn[0:nmax],alt_dyn[0:nmax],'g-')
ax_T.plot(theta(T_dyn[0:nmax]*(1+1.608*r_dyn[0:nmax])/(1+r_dyn[0:nmax]),p_std(alt_dyn[0:nmax],Gamma)),alt_dyn[0:nmax],'r-')

ax_T.axis([270, 310, 0, 4000])                     # limite des axes (xmin,xmax,ymin,ymax)
ax_T.set_xlabel("Température (K)")                     # titre de l'axe des abscisses
ax_T.set_ylabel("Altitude (m)")                               # titre de l'axe des ordonnees
ax_T.title.set_text("Profil de température") 

# Tracé du profil de pression
ax_p.plot(p_std(altitude,Gamma),altitude)

ax_p.axis([60000, 102000, 0, 4000])                     # limite des axes (xmin,xmax,ymin,ymax)
ax_p.set_xlabel("Pression (Pa)")                     # titre de l'axe des abscisses
ax_p.set_ylabel("Altitude (m)")                               # titre de l'axe des ordonnees
ax_p.title.set_text("Profil de pression") 

# Tracé de l'évolution dynamique de la parcelle
ax_alt.plot(temps[0:nmax],alt_dyn[0:nmax])
ax_alt.axis([0, 2000, 0, 4000])                     # limite des axes (xmin,xmax,ymin,ymax)
ax_alt.set_xlabel("Temps (s)")                     # titre de l'axe des abscisses
ax_alt.set_ylabel("Altitude (m)")                               # titre de l'axe des ordonnees
ax_alt.title.set_text("Évolution adiabatique d'une masse d'air humide") 

ax_Tdyn=ax_alt.twinx()
ax_Tdyn.plot(temps[0:nmax],T_dyn[0:nmax],'r-')

ax_Tdyn.axis([0, 2000, 270, 310])                     # limite des axes (xmin,xmax,ymin,ymax)
ax_Tdyn.set_xlabel("Temps (s)")                     # titre de l'axe des abscisses
ax_Tdyn.set_ylabel("Température")                               # titre de l'axe des ordonnees

# Tracé de l'évolution de l'humidité relative

ax_RH.plot(temps[0:nmax],pw_dyn[0:nmax]/psatw(T_dyn[0:nmax]))

ax_RH.axis([0, 2000, 0, 1.25])                     # limite des axes (xmin,xmax,ymin,ymax)
ax_RH.set_xlabel("Temps (s)")                     # titre de l'axe des abscisses
ax_RH.set_ylabel("Humidité relative")                               # titre de l'axe des ordonnees

# Tracé de l'évolution du contenu en eau liquide

ax_qc.plot(temps[0:nmax],qc_dyn[0:nmax])

ax_qc.axis([0, 2000, 0, 3e-3])                     # limite des axes (xmin,xmax,ymin,ymax)
ax_qc.set_xlabel("Temps (s)")                     # titre de l'axe des abscisses
ax_qc.set_ylabel("LWC (g/m$^3$)")                               # titre de l'axe des ordonnees

# Mise à jour des tracés par changement de slider ou de mode de simulation
def update(val):
    global alt_dyn,vit_dyn,T_dyn,pw_dyn,qc_dyn,r_dyn
    T_ini     = sl_axT.val          #Slider pour modifier la température initiale
    RH_ini    = sl_axRH.val         #Slider pour modifier l'humidité initiale'
    Gamma     = sl_axGamma.val*1e-3 #Slider pour modifier le taux de refroidissement de l'atmosphère
    pas_temps = sl_axdt.val         #Slider pour modifier le pas de temps
    condrate=sl_axcond.val                        #Slider pour modifier la vitesse

    alt_dyn=np.zeros(4000)
    vit_dyn=np.zeros(4000)
    T_dyn=np.zeros(4000)
    pw_dyn=np.zeros(4000)
    qc_dyn=np.zeros(4000)
    r_dyn=np.zeros(4000)   
    
    nmax=int(np.floor(2000/pas_temps))
    temps = np.arange(0,4000*pas_temps,pas_temps)
    Mini_descam(pas_temps, T_ini, RH_ini, Gamma, radio.value_selected,condrate)

    ax_T.lines[0].set_xdata(T_std(altitude,Gamma))
    ax_T.lines[1].set_xdata(theta(T_std(altitude,Gamma),p_std(altitude,Gamma)))
    ax_T.lines[2].set_data(T_dyn[0:nmax],alt_dyn[0:nmax])
    ax_T.lines[3].set_data(theta(T_dyn[0:nmax]*(1+1.608*r_dyn[0:nmax])/(1+r_dyn[0:nmax]),p_std(alt_dyn[0:nmax],Gamma)),alt_dyn[0:nmax])
    
    ax_p.lines[0].set_xdata(p_std(altitude,Gamma))
    
    ax_alt.lines[0].set_data(temps[0:nmax],alt_dyn[0:nmax])
    ax_Tdyn.lines[0].set_data(temps[0:nmax],T_dyn[0:nmax])
    
    ax_RH.lines[0].set_data(temps[0:nmax],pw_dyn[0:nmax]/psatw(T_dyn[0:nmax]))
    
    ax_qc.lines[0].set_data(temps[0:nmax],qc_dyn[0:nmax])
    
sl_axT.on_changed(update)
sl_axRH.on_changed(update)
sl_axGamma.on_changed(update)
sl_axdt.on_changed(update)
sl_axcond.on_changed(update)

radio.on_clicked(update)

# ## Definition d'un bouton reset
# axcolor = 'lightgoldenrodyellow'                            # couleur des barres
# resetax = plt.axes([.82, 0.66, 0.06, 0.04])
# button = Button(resetax, 'Reset', color=axcolor, hovercolor='0.975')
    
# def reset(event):
#     sl_axT.reset()
#     sl_axRH.reset()
#     sl_axGamma.reset()
#     sl_axdt.reset()
    
# button.on_clicked(reset)

# Affichage de la figure
plt.show()